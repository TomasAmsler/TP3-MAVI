#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;

sf::Transformable;
Texture texture;
Sprite sprite;



//VARIABLES
int main()
{
	//Cargamos la textura del archivo
	texture.loadFromFile("cuad_red.png");

	//Cargamos el material del sprite
	sprite.setTexture(texture);

	//achico sprite 

	//Creamos la ventana
	sf::RenderWindow App(sf::VideoMode(800, 600, 32),
		"Sprite que gira y gira");

	// Posiciono la imagen en el centro
	sprite.setPosition(250, 150);

	float rotation = sprite.getRotation();

	sprite.setRotation(45.0f);
	
	// Loop principal 
	while (App.isOpen())
	{
		//Con el sprite.rotate en 0.01 para que no gire a toda velocidad
		sprite.rotate(0.01);
		
		// Limpiamos la ventana 
		App.clear();
		
		// Dibujamos la escena 
		App.draw(sprite);
		
		// Mostramos la ventana 
		App.display();
	}
	return 0;
}