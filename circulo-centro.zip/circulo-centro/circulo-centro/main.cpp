
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
using namespace sf;

Texture texture;
Sprite sprite;


int main() {
	
	texture.loadFromFile("rcircle-blue.png");
	
	sprite.setTexture(texture);

	sprite.setPosition(Vector2f(400, 270));

	Vector2f scale = sprite.getScale();
	Rect<float> size = sprite.getGlobalBounds();
	sprite.setOrigin(Vector2f(size.width / 2, size.height / 2));
	
	//Ventana
	sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Circulo en el centro");

	//Loop principal
	while (App.isOpen()) {
		//Limpio ventana
		App.clear();

		App.draw(sprite);

		App.display();
	}
	return 0;
}
