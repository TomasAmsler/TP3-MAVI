#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
using namespace sf;

Texture texture_red;
Texture texture_black;
Texture texture_blue;
Texture texture_yellow;

Sprite sprite_red;
Sprite sprite_black;
Sprite sprite_blue;
Sprite sprite_yellow;

float escalaX; float escalaY;
float height_red, width_red;
float height_black, width_black;
float height_blue, width_blue;
float height_yellow, width_yellow;

int main() {
    // Crear la ventana de visualizaci�n
    sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Cambiar tama�o de un Sprite en SFML");

    texture_red.loadFromFile("cuad_red.png");
    texture_yellow.loadFromFile("cuad_yellow.png");
    texture_blue.loadFromFile("cuad_blue.png");

   // texture_black.loadFromFile("chessb.png");
    // Crear el sprite y asignar la textura cargada
    Sprite sprite_red(texture_red);
   // Sprite sprite_black(texture_black);
    Sprite sprite_yellow(texture_yellow);
    Sprite sprite_blue(texture_blue);

    sprite_red.setPosition(0, 0);
    //sprite_black.setPosition(400,0);
    sprite_yellow.setPosition(400, 0);
    sprite_blue.setPosition(0, 333);
    
    // Escalar el sprite a la mitad de su tama�o original
    sprite_red.setScale(1.9f, 1.3f);
    sprite_yellow.setScale(1.3f, 0.65f);
    sprite_blue.setScale(3.15f, 2.95f);
/*
    height_red = (float)texture_red.getSize().y;
    height_gris = (float)texture_gris.getSize().y;
    width_red = (float)texture_red.getSize().x;
    width_gris = (float)texture_gris.getSize().x;
   escalaY = height_gris / height_red; escalaX =
        width_gris / width_red;
    //sprite_red.setScale(escalaX, escalaY);
    */

    while (App.isOpen()) {

        App.clear();
        // Dibujar el sprite en la ventana
        App.draw(sprite_red);
        //App.draw(sprite_black);
        App.draw(sprite_yellow);
        App.draw(sprite_blue);
        App.display();
    }

    return 0;
}
