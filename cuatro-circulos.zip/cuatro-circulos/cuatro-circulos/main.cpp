//////Bibliotecas//////
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
using namespace sf;
//////Variables
Texture texture_color;
Texture texture_bw;
Texture texture_right;
Texture texture_left;

Sprite sprite_color;
Sprite sprite_bw;
Sprite sprite_right;
Sprite sprite_left;

float escalaX; float escalaY;
float height_color, width_color;
float height_bw, width_bw;
float height_left, width_left;
float height_right, width_right;

///Punto de entrada a la aplicaci�n///
int main() {
	//Cargamos la textura del archivo
	texture_color.loadFromFile("rcircle.png");
	texture_bw.loadFromFile("rcircle.png");
	texture_left.loadFromFile("rcircle.png");
	texture_right.loadFromFile("rcircle.png");
	//Cargamos el material del sprite
	sprite_color.setTexture(texture_color);
	sprite_bw.setTexture(texture_bw);
	sprite_left.setTexture(texture_left);
	sprite_right.setTexture(texture_right);
	//Movemos el sprite
	sprite_color.setPosition(666, 0);
	sprite_left.setPosition(0, 455);
	sprite_right.setPosition(666, 450);



	//Creamos la ventana
	sf::RenderWindow App(sf::VideoMode(800, 600, 32),
		"cuatro circulos");
	// Loop principal 
	while (App.isOpen()) {
		// Limpiamos la ventana 
		App.clear();
		// Dibujamos la escena 
		App.draw(sprite_color);
		App.draw(sprite_bw);
		App.draw(sprite_left);
		App.draw(sprite_right);

		// Mostramos la ventana 
		App.display();
	}
	return 0;
}