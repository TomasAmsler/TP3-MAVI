#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>

using namespace sf;

Texture texture;
Sprite sprite;



//VARIABLES
int main()
{
	//Cargamos la textura del archivo
	texture.loadFromFile("fondo.jpg");
	
	//Cargamos el material del sprite
	sprite.setTexture(texture);

	//achico sprite 
	
	//Creamos la ventana
	sf::RenderWindow App(sf::VideoMode(800, 600, 32),
		"Que ventana horrible");
	
	
	
	// Loop principal 
	while (App.isOpen())
	{
		// Limpiamos la ventana 
		App.clear();
		// Dibujamos la escena 
		App.draw(sprite);
		texture.setSmooth(true);
		// Mostramos la ventana 
		App.display();
	}
	return 0;
}




