// Importa la biblioteca SFML
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>

using namespace sf;
int main() {
    // Crea una ventana
    sf::RenderWindow window(sf::VideoMode(800, 800), "Ajedrez");

    // Carga las imágenes de las casillas blancas y negras
    sf::Texture chesswTexture;
    if (!chesswTexture.loadFromFile("chessw.png")) {
        return 1;
    }
    Texture chessbTexture;
    if (!chessbTexture.loadFromFile("chessb.png")) {
        return 1;
    }



    // Inicia el bucle de renderizado
    const int tileSize = 100;

    while (window.isOpen()) {
        // Procesa los eventos
        sf::Event event;
        while (window.pollEvent(event)) {
            // Cierra la ventana si se presiona la tecla escape
            if (event.type == sf::Event::Closed) {
                window.close();
            }
        }
                // Redibuja la ventana
        window.clear();
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                sf::Sprite square;
                square.setTexture((row + col) % 2 == 0 ? chesswTexture : chessbTexture);
                square.setPosition(col * tileSize, row * tileSize);
                window.draw(square);
            }
        }
       /* window.draw(sprite_blanca);
        window.draw(sprite_negra);*/
        window.display();
    }

    return 0;
}
